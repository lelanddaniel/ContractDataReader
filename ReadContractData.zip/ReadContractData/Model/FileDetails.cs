﻿namespace ReadContractData.Model
{
    public class FileDetails
    {
        public string? Name { get; set; }
        public List<string> Fields { get; set; }

        public static FileDetails CreateFrom(string fileName, List<string> fields)
        {
            return new FileDetails()
            {
                Name = fileName,
                Fields = fields.Distinct().ToList(),
            };
        }
    }
}
