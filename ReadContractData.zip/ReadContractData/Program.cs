﻿// See https://aka.ms/new-console-template for more information
using Services.ReadContractData;

ReadDirectoryService readDirectory = new ReadDirectoryService();
ReadFilesService readFiles = new ReadFilesService();
WriteFileService writeFile = new WriteFileService();

string fileSaveDirectory = @"C:\Users\LDaniel\Desktop\Contracts\testing\";
string targetDirectory = @"C:\_development\Transactions\Carvana.Contracts\Carvana.Contracts.PdfGeneration\PDFs";

var files = readDirectory.DirectorySearch(targetDirectory);

var listOfFields = readFiles.ReadPDFsFormFields(files);

writeFile.WriteFieldsToFile(listOfFields, fileSaveDirectory);