﻿namespace Services.ReadContractData
{
    internal class ReadDirectoryService
    {
        List<string> files = new List<string>();

        public List<string> DirectorySearch(string directory)
        {            
            try
            {
                foreach (string f in Directory.GetFiles(directory, "*.pdf"))
                {
                    files.Add(f);
                }

                foreach (string d in Directory.GetDirectories(directory))
                {
                    foreach (string f in Directory.GetFiles(d, "*.pdf"))
                    {
                        files.Add(f);
                    }

                    foreach(string f in Directory.GetDirectories(d))
                    {
                        DirectorySearch(f);
                    }
                }
            }
            catch (Exception ex)
            {
                
            }

            return files;
        }
    }
}
