﻿using iTextSharp.text.pdf;
using ReadContractData.Model;
using System.Text.RegularExpressions;

namespace Services.ReadContractData
{
    internal class ReadFilesService
    {
        public List<FileDetails> ReadPDFsFormFields(List<string> files)
        {
            var allFileDetails = new List<FileDetails>();
            try
            {
                foreach (string file in files)
                {
                    var formFields = GetPDFsFormFields(file);
                    var fields = GetListOfFormFieldNames(formFields);
                    var fileName = GetFilesName(file);
                    allFileDetails.Add(FileDetails.CreateFrom(fileName, fields));
                }
            }
            catch (Exception ex)
            {

            }

            return allFileDetails;
        }

        private string GetFilesName(string filePath)
        {
            var filePath2 = filePath.Split("\\");
            var fileName = filePath2[filePath2.Length - 1].Split(".")[0];
            var fileDirectory = filePath2[filePath2.Length - 2];
            return fileDirectory + " - " + fileName + ".txt";
        }

        private IDictionary<string, AcroFields.Item> GetPDFsFormFields(string file)
        {
            PdfReader pdfReader = new PdfReader(file);
            return pdfReader.AcroFields.Fields;
        }


        private List<string> GetListOfFormFieldNames(IDictionary<string, AcroFields.Item> formFields)
        {
            var fields = new List<string>();

            foreach (KeyValuePair<string, AcroFields.Item> field in formFields)
            {
                var fieldName = Regex.Replace(field.Key, "\\#[0-9]+", "");
                fields.Add(fieldName);
            }

            return fields;
        }
    }
}
